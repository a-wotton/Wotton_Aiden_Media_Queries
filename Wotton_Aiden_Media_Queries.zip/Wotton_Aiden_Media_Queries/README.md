# Wotton_Aiden_Media_Queries
This page is practice for setting up media queries for different sizes, creating responsive design.

## Usage
Adjust the size of the viewing window to test the site's responsivness.

## Credits
Aiden Wotton

## License
MIT
